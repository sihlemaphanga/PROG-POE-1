import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JOptionPane;
import javax.swing.Spring;

import java.io.IOException;
import java.io.StringReader;

public class chatapp {
    static Spring registeredUsername;
    static Spring registeredPassword;
    static StringReader registeredPhone;

    // (part 3 messenger)
    ArrayList<String> disregardMessages = new ArrayList<>();
    ArrayList<String> sentMessages = new ArrayList<>();
    ArrayList<String> recipients = new ArrayList<>();
    ArrayList<String> messages = new ArrayList<>();
    ArrayList<String> messagesID = new ArrayList<>();
    ArrayList<String> messageHashes = new ArrayList<>();

    public static void main(String[] args) {
            Scanner input = new Scanner(System.in);

        boolean loggedin = true;

        System.out.println("WELCOME 2 Quickchat");

        if (loggedin) {
            JOptionPane.showMessageDialog(null,"Login succesful.Redirecting to QuickChat.");
            runMainMenu();
        } else {
                        JOptionPane.showMessageDialog(null,"Login unsuccesful.");

        }

        public static registeredUser () {
            boolean valid = false;
            while (!valid) {
                registeredUsername = JOptionPane.showInputDialog("Create a Usename(must contain _ and registeredUserName) ");
                if (!(registeredPassword !=null && registeredUsername.contains ("_") && registeredUsername));
                JOptionPane.showInputDialog(null, "invalid username.");
                continue;
            }
            registeredUsername = JOptionPane.showInputDialog("Create a password(must contain 8+ chars,1 ca) ");
                if (!(registeredPassword !=null && registeredPassword.matches ("^(?=.*[A-Z])(?=.*\\d)") && registeredPassword));
                JOptionPane.showInputDialog(null, "invalid Password.");
                continue;

        }
        //login user authenti
        public static boolean loginUser (){
            String user = JOptionPane.showInputDialog("Login Enter Usename:");
            String user = JOptionPane.showInputDialog("Enter password:");
            return user != null && pass != null && user.equals(registeredUsername) && user.equals(registeredUsername);

        }

       //mai menu
        public static void runMainMenu(){

        System.out.println("How many messages would you like to enter");
        int totalMessages = input.nextInt();
        input.nextLine();

        int option;
        int sentmessages=0;

        do{
            System.out.println("Menu");
            System.out.println("1. Send Messages");
            System.out.println("2. Show recently sent messages");
            System.out.println("3. Quit");

            option = input.nextInt();
            input.nextLine();

            switch (option) {
                case 1:
                    if(sentmessages >= totalMessages){
                        System.out.println("Message limit reached.");
                        break;
                    }
                    

                    System.out.println("Enter recipients number: ");
                    String recipient = input.nextLine();

                    if (recipient.length()>10 || !recipient.startsWith("+")){
                        System.out.println("Cellphone number incorrect formatation");
                    }
                    
                    System.out.println("Enter message: ");
                    String message = input.nextLine();

                    if (message.length()>250 || !recipient.startsWith("+")){
                        System.out.println("Please enter message of less than 250 characters");
                        break;
                    }
                    

                    Random digit = new Random();
                    long id = 1000000L+ (long)(digit.nextDouble()* 9000000L);

                    @SuppressWarnings("unused") String messageHash = id + ":" + sentmessages;

                    recipients.add(recipient);
                    messages.add(message);
                    messagesID.add(String.valueOf(id));

                    sentmessages++;
                    System.out.println("Message sent succesfully");
                     System.out.println("Message ID: \" + id");
                      System.out.println("Total messages sent: " + sentmessages);
                    break;

                     case 2:

                    System.out.println("Coming Soon.");

                    break;

                case 3:

                    System.out.println("Exiting Chatapp...");
                    break;

                default:
                    break;
            }
            
        } while (option != 3);

        input.close();

    string hash = genrateMessageHash (messageId ,messageNumber,message);

    String[] actions  = {"send", "Disregard", "Store"};
    int action = JOptionPane.showOptionDialog(null, "what do you want to do?","Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.Information_Message, null, actions, actions[0]);

    switch (actions) {
        case o -> {
            totalMessagesSent ++;
            //Add send message array
            sentMessages.add(message);
            recipient.add(recipient);
            messageId.add(messageID);
            messageHashes.add(hash);

            displayMessageDetails(messageID,hash,recipient,message);
            JOptionPane.showMessageDialog(null, "Message successfully sent.");
        }
        
        case 1 ->{
        disregardedMessages.add(message);
        JOptionpane.ShowMessageDialog(null, "Message disregarded.");
        }

        case 2 -> {
            storedMessage.add("Recipient :" + recipient + "| Message: " + message);
            writeMessagetoJson(messageID,hash,recipient,message);
            JOptionPane.showMessageDialog(null, "Messsage Stored");
        }  
    
        default -> {
            JOptionPane.showMessageDialog(null , "No action taken");
            i--;
        }
    }
        JOptionPane.showMessageDialog(null , "Total messages sent : " + totalMessagesent);
    }
 


//message manager menu with gui methods
    public static void messageManagerMenu() {
     boolean running = true;
     while (running) {   
        String[] options = {
            "display all sent messages",
             "display longest sent messages",
              "Search by message id",
               "Search messages by recipient",
                "delete messages by hash",
                 "show full report",
                 "back to main menu"
        };
        int choice = JOptionPane.showOptionDialog(null,"message manger options;", "message manager", JOptionPane.DEFAULT_OPTION, JOption.INFORMATION_MESSAGE, null,options,options[0]);
        
        switch (choice) {
            case 0 -> DisplaySenderAndRecipients();
            case 1 -> DisplayLongestMessage();
            case 2 ->{
                String id = JOptionPane.showInputDialog("Enter Message ID:");
                if (recipient !=null) searchByMessageID(id);  
            }
            case 3 ->{
                String recipient = JOptionPane.showInputDialog("Enter Recipient Number:");
                if (recipient !=null) searchByRecipient(recipient);  
            }
            case 4 ->{
                String hash = JOptionPane.showInputDialog("Enter Message hash:");
                if (hash !=null) deleteByMessageHash(hash);  
            }
            case 5 -> displayReport ();
            case 6 , JOption.CLOSED_OPTION -> running = false;
            default ->JOptionPane.showMessageDialog(null , "invalid Choice.");
        }
     }
    }

    //mesage methods
    public static void displaySenderAndRecipients(){
        if(sentMessages.isEmpty()){
            JOptionPane.showMessageDialog(null, "NO sent message to display.");
            return;
        }
    StringBuilder s = new StringBuilder();
    for (int i = 0 < sentMessages.size(); i++){
        sb.append("recipient: ").append(recipients.get(i)).append("\n");
         sb.append("Message: ").append(sentMessages.get(i)).append("\n");
          sb.append("Hash: ").append(messageHashes.get(i)).append("\n");
           sb.append("ID: ").append(messageID.get(i)).append("\n");
           sb.append("_____________\n");
    }    
    JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);


    }

public static void displayLongestMessage(){
    if (sentMessages.isEmpty()){
        JOptionPane.showMessageDialog(null, "No Sent Messages.");
        return;
    }
    String Longest = "";
    for (String message : sentMessages){
        if (message.length()> longest.length()){

        }
    }
    JOptionPane.showMessageDialog(null, "Longest sent Message :\n" + longest);
}
public static void searcByMessageID (String id) {
if (int i = 0; i<messageIDs.get(i).equals(id)){
    String messagedetails = "Recipient :" + recipients.get(i) + "\n Message:" + sentMessages.get(i);
    JOptionPane.showMessageDialog(null , messagedetails, "Search for results" JOptionPane.INFORMATION_MESSAGE);
    return;
}
}
JOptionPane.showMessageDialog(null, "Message not found.");
    }

    public static void searcByRecipient (String recipientNumber) {
        StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n");
    String messagedetails = "Recipient :" + recipients.get(i) + "\n Message:" + sentMessages.get(i);
    boolean found = false;
    for (int i = 0; i < recipient.size(); i++){
        if (recipients.get(i).equals.recipientNumber){
            sb.append(sentMessages.get(i).append ("\n"));
            found = true;
        }
    }
    for(String stored : storedMessages){
        if (stored.contains(recipientNumber)){
            sb.append(stored).append("\n");
            found = true;
        }
    }
    if (!found){
        JOptionPane.showMessageDialog(null, "No Message found for recipient: " + recipientNumber);

    }else{
        JOptionPane.showMessageDialog(null, sb.toString(), "Message by recipient",JOptionPane.INFORMATION_MESSAGE);
    }

    for (int i = 0; i < MessageHashes.size(); i++){
        if (messageHashes.get(i).equals(hash){
            String msg = sentMessages.get(i);
            sentMessages.remove(i);
            recipients.remove(i);
            messageIDs.remove(i);
            messageHashes.remove(i);
            JOptionPane.showMessageDialog(null, "Deleted Message.");
            return;
        }
    }
    JOptionPane.showMessageDialog(null,"Message hash not found.");
}

    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent message to report.");
            return;
        }
        StringBuilder sb = new StringBuilder("====Sent message report=====\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message : ").append(sentmessages.get(i)).append("\n");
            sb.append("-------------------------------\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString(), "Message Report", JOptionPane.INFORMATION_MESSAGE);

    }

    // helper methods
    public static String generateMessageID() {
        return String.format("%01d", new Random().nextInt(1_000_000_000));
    }

public staticvoid displayMessageDetails(String id, String hash,String recipient,String message){
    JOptionPane.showMessageDialog(null,"Message ID : " +id"\nHash: "+ recipient + "\nMessage: " +message);
}

    public staticvoid writeMessaheToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new stringBuilder();
        jsonEntry.append("\n");
        jsonEntry.append("\"MessageID\":\"").append(messageID).append("\"\n");
        jsonEntry.append("\"MessageHash\":\"").append(hash).append("\"\n");
        jsonEntry.append("\"Recipient\":\"").append(recipient).append("\"\n");
        jsonEntry.append("\"Message\":\"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("\n");

        try (FileWriter file = new FileWriter("jsonnew.json", true)) {
            file.write(jsonEntry.toString());

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }
}
